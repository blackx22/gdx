<?php
    
    $GdxCurrentTime = time();

    function FormatNetFramework($NetFrameworkInfo)
    {
        $Result = "";
        $NetFrameworks = explode("|", $NetFrameworkInfo);
        $Count = count($NetFrameworks);
        
        if($Count)
        {
            $Result .= $Count;
            for($c = 0; $c < $Count; $c++)
            {
                $NetVersion = explode(",", $NetFrameworks[$c]);
                if(count($NetVersion) == 2)
                {
                    $Result .= "
                            <div class='gdx-clt-info-block'>
                                <div class='gdx-cltdet' style='padding-left: 10px'>
                                    <span class='cbold'>NET Framework: </span>";
                                
                    $Result .= $NetVersion[0];
                    
                    if(strlen($NetVersion[1]))
                    {
                        $Result .= " <span class='cbold'>Servipack:</span> {$NetVersion[1]}";
                    }
                                
                    $Result .= "</div>
                            </div>";
                }
            }
        }
        
        return $Result;
    }
    
    function FormatBrowsers($BrosersInfo)
    {
        
        
    }
    
    function FormatHardDrives($HardDrivesInfo)
    {
        $HDBytes = 0;
        $HDSub = "";

        $HardDrives = explode("|", $HardDrivesInfo);
        for($c = 0; $c < count($HardDrives); $c++)
        {
            $Drive = explode(",", $HardDrives[$c]);
            if(count($Drive) == 3)
            {
                $CapBytes = 0;
                $CapMb = 0;

                $HDSub .= "
                            <div class='gdx-clt-info-block'>
                                <div class='gdx-cltdet'>
                            ";

                $SymbolicLink = $Drive[0];
                $HDSub .= "       <span class='cbold'>Symbolic Link:</span> {$SymbolicLink} | ";

                $CapBytes = $Drive[1];
                $CapMb = floor($CapBytes / (1024 * 1024));
                $HDSub .= "<span class='cbold'>Capacity:</span> {$CapMb} MB | ";

                $Partitions = $Drive[2];
                $HDSub .= "<span class='cbold'>Number Of Partitions:</span> {$Partitions}";

                $HDSub .= 
                        "
                                </div>
                            </div>";
                    
                $HDBytes += $CapBytes;
            }
        }

        $HDMB = floor($HDBytes / (1024 * 1024));
        $HDGB = floor($HDMB / 1024);
        $HD = "{$HDMB} MB ({$HDGB} GB)\r\n"; 
        return $HD . $HDSub;
    }

    function FormatPhysicalMemories($PhysicalMemoriesInfo)
    {
        $PhysicalMemoryBytes = 0;
        $PMsub = "";

        $Memories = explode("|", $PhysicalMemoriesInfo);
        for($c = 0; $c < count($Memories); $c++)
        {
            $Memory = explode(",", $Memories[$c]);
            if(count($Memory) == 2)
            {
                $MemBytes = 0;
                $MemMb = 0;

                $PMsub .= "
                    <div class='gdx-clt-info-block'>
                        <div class='gdx-cltdet'>
                            ";

                $MemoryType = $Memory[0];
                $PMsub .= "<span class='cbold'>Type:</span> {$MemoryType} | ";

                $MemBytes = $Memory[1];
                $MemMb = floor($MemBytes / (1024 * 1024));
                $PMsub .= "<span class='cbold'>Capacity:</span> {$MemMb} MB";

                $PMsub .= "
                        </div>
                    </div>";
                    
                $PhysicalMemoryBytes += $MemBytes;
            }
        }

        $PhysicalMemoryMB = floor($PhysicalMemoryBytes / (1024 * 1024));
        $PhysicalMemoryGB = floor($PhysicalMemoryMB / 1024);
        $PM = "{$PhysicalMemoryMB} MB ({$PhysicalMemoryGB} GB)\r\n";
        return $PM . $PMsub;
    }
    
    function GetIPAddress() 
    {
        $IPKeys = array("HTTP_CLIENT_IP", "HTTP_X_FORWARDED_FOR", "HTTP_X_FORWARDED", "HTTP_X_CLUSTER_CLIENT_IP", "HTTP_FORWARDED_FOR", "HTTP_FORWARDED", "REMOTE_ADDR");
        foreach ($IPKeys as $Key) 
        {
            if (array_key_exists($Key, $_SERVER) === true) 
            {
                foreach (explode(',', $_SERVER[$Key]) as $IP) 
                {
                    $IP = trim($IP);
                    if (IsValidIP($IP))
                    {
                        return $IP;
                    }
                }
            }
        }

        return isset($_SERVER["REMOTE_ADDR"]) ? $_SERVER["REMOTE_ADDR"] : false;
    }

    function IsValidIP($IP)
    {
        if (filter_var($IP, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_IPV6 | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === FALSE) 
        {
            return false;
        }

        return true;
    }

    function BuildHexSz32()
    {
        $HexSz = '';
        for( $i = 0; $i < 32; $i++) 
        {
            while(true)
            {
                $Val = mt_rand(48, 90);
                if(($Val >= 48 && $Val <= 57) || ($Val >= 65 && $Val <= 70))
                {
                    break;
                }
            }
            $HexSz .= chr($Val);
        }
        return $HexSz;
    }
    
    function GetOperatingSystemSzToMask($OperatingSystemSz)
    {
        if(!isset($OperatingSystemSz))
        {
            return 0;
        }

        if($OperatingSystemSz == ALL_OPERATING_SYSTEMS_SZ)
        {
            return ALL_OPERATING_SYSTEMS_MASK;
        }
        if($OperatingSystemSz == WINDOWS_XP_SZ)
        {
            return WINDOWS_XP_MASK;
        }
        else if($OperatingSystemSz == WINDOWS_2003_SZ)
        {
            return WINDOWS_2003_MASK;
        }
        else if($OperatingSystemSz == WINDOWS_VISTA_SZ)
        {
            return WINDOWS_VISTA_MASK;
        }
        else if($OperatingSystemSz == WINDOWS_7_SZ)
        {
            return WINDOWS_7_MASK;
        }
        else if($OperatingSystemSz == WINDOWS_8_SZ)
        {
            return WINDOWS_8_MASK;
        }
        else if($OperatingSystemSz == WINDOWS_8_1_SZ)
        {
            return WINDOWS_8_1_MASK;
        }
        else if($OperatingSystemSz == WINDOWS_10_SZ)
        {
            return WINDOWS_10_MASK;
        }

        return 0;
    }

    function GetOperatingSystemMaskToSz($OperatingSystemsMask)
    {
        if(!isset($OperatingSystemsMask))
        {
            return "Unknown";
        }

        if($OperatingSystemsMask & ALL_OPERATING_SYSTEMS_MASK)
        {
            return ALL_OPERATING_SYSTEMS_SZ;
        }

        $Sz = "";
        if($OperatingSystemsMask & WINDOWS_XP_MASK)
        {
            if(strlen($Sz)) $Sz .= ", ";
            $Sz .= WINDOWS_XP_SZ;
        }
        if($OperatingSystemsMask & WINDOWS_2003_MASK)
        {
            if(strlen($Sz)) $Sz .= ", ";
            $Sz .= WINDOWS_2003_SZ;
        }
        if($OperatingSystemsMask & WINDOWS_VISTA_MASK)
        {
            if(strlen($Sz)) $Sz .= ", ";
            $Sz .= WINDOWS_VISTA_SZ;
        }
        if($OperatingSystemsMask & WINDOWS_7_MASK)
        {
            if(strlen($Sz)) $Sz .= ", ";
            $Sz .= WINDOWS_7_SZ;
        }
        if($OperatingSystemsMask & WINDOWS_8_MASK)
        {
            if(strlen($Sz)) $Sz .= ", ";
            $Sz .= WINDOWS_8_SZ;
        }
        if($OperatingSystemsMask & WINDOWS_8_1_MASK)
        {
            if(strlen($Sz)) $Sz .= ", ";
            $Sz .= WINDOWS_8_1_SZ;
        }
        if($OperatingSystemsMask & WINDOWS_10_MASK)
        {
            if(strlen($Sz)) $Sz .= ", ";
            $Sz .= WINDOWS_10_SZ;
        }
        if(!(strlen($Sz) > 0))
        {
            return "Unknown";
        }

        return $Sz;
    }

    function GetOperatingSystemIntToSz($OSVerInterger)
    {
        if(!isset($OSVerInterger))
        {
            return "Unknown";
        }

        if ($OSVerInterger == WINDOWS_XP)
        {
            return WINDOWS_XP_SZ;
        }
        else if ($OSVerInterger == WINDOWS_2003)
        {
            return WINDOWS_2003_SZ;
            }
        else if ($OSVerInterger == WINDOWS_VISTA)
        {
            return WINDOWS_VISTA_SZ;
        }
        else if ($OSVerInterger == WINDOWS_7)
        {
            return WINDOWS_7_SZ;
        }
        else if ($OSVerInterger == WINDOWS_8)
        {
            return WINDOWS_8_SZ;
        }
        else if ($OSVerInterger == WINDOWS_8_1)
        {
            return WINDOWS_8_1_SZ;
        }
        else if ($OSVerInterger == WINDOWS_10)
        {
            return WINDOWS_10_SZ;
        }
        return "Unknown";
    }

    function GetOperatingSystemSzToInt($OSSz)
    {
        if(!isset($OSSz))
        {
            return 0;
        }

        if ($OSSz == WINDOWS_XP_SZ)
        {
             return WINDOWS_XP;
        }
        else if ($OSSz == WINDOWS_2003_SZ)
        {
            return WINDOWS_2003;
        }
        else if ($OSSz == WINDOWS_VISTA_SZ)
        {
            return WINDOWS_VISTA;
        }
        else if ($OSSz == WINDOWS_7_SZ)
        {
            return WINDOWS_7;
        }
        else if ($OSSz == WINDOWS_8_SZ)
        {
            return WINDOWS_8;
        }
        else if ($OSSz == WINDOWS_8_1_SZ)
        {
            return WINDOWS_8_1;
        }
        else if ($OSSz == WINDOWS_10_SZ)
        {
            return WINDOWS_10;
        }

        return "Unknown";
    }

    function GetOperatingSystemIntToMask($OSInteger)
    {
        if(!isset($OSInteger))
        {
            return 0;
        }

        if($OSInteger == WINDOWS_XP)
        {
            return WINDOWS_XP_MASK;
        }
        else if($OSInteger == WINDOWS_2003)
        {
            return WINDOWS_2003_MASK;
        }
        else if($OSInteger == WINDOWS_VISTA)
        {
            return WINDOWS_VISTA_MASK;
        }
        else if($OSInteger == WINDOWS_7)
        {
            return WINDOWS_7_MASK;
        }
        else if($OSInteger == WINDOWS_8)
        {
            return WINDOWS_8_MASK;
        }
        else if($OSInteger == WINDOWS_8_1)
        {
            return WINDOWS_8_1_MASK;
        }
        else if($OSInteger == WINDOWS_10)
        {
            return WINDOWS_10_MASK;
        }

        return 0;
    }

    function GetOSArchitectureSz($OSArchBool)
    {
        if (isset($OSArchBool))
        {
            if ($OSArchBool == true)
            {
                return "64-bit";
            }
            else if ($OSArchBool == false)
            {
                return "32-bit";
            }
        }
        return "Unknown";
    }

    function AddrType($IPAddress)
    {
        if (ip2long($IPAddress) !== false)
            return "ipv4";
        else if (preg_match('/^[0-9a-fA-F:]+$/', $IPAddress) && inet_pton($IPAddress))
            return "ipv6";
        else
            return "unknown";
    }
    
    function GetComputerType($TypeInt)
    {
        if (isset($TypeInt))
        {
            switch ($TypeInt) {
                case 1:
                    return "Other";
                case 3:
                    return "Desktop";
                case 4:
                    return "Low Profile Desktop";
                case 5:
                    return "Pizza Box";
                case 6:
                    return "Mini Tower";
                case 7:
                    return "Tower";
                case 8:
                    return "Portable";
                case 9:
                    return "Laptop";
                case 10:
                    return "Notebook";
                case 11:
                    return "Hand Held";
                case 12:
                    return "Docking Station";
                case 13:
                    return "All in One";
                case 14:
                    return "Sub Notebook";
                case 15:
                    return "Space-Saving";
                case 16:
                    return "Lunch Box";
                case 17:
                    return "Main System Chassis";
                case 18:
                    return "Expansion Chassis";
                case 19:
                    return "SubChassis";
                case 20:
                    return "Bus Expansion Chassis";
                case 21:
                    return "Peripheral Chassis";
                case 22:
                    return "Storage Chassis";
                case 23:
                    return "Rack Mount Chassis";
                case 23:
                    return "Sealed-Case PC";
            }
        }
        return "Unknown";
    }
    
    function GetCPUArchitecture($ArchitectureInt)
    {
        if (isset($ArchitectureInt))
        {
            if ($ArchitectureInt == 0)
            {
                return "x86";
            }
            else if ($ArchitectureInt == 6)
            {
                return "Itanium";
            }
            else if ($ArchitectureInt == 9)
            {
                return "x64";
            }
        }
        return "Unknown";
    }
    
    function GetSzDateTimeFromTimeStamp($TimeStamp)
    {
        if(!isset($TimeStamp))
        {
            return "Unknown";
        }
        return date("d-m-Y g:i A", $TimeStamp);
    }

    function FormatURL($URL)
    {
        $Result = $URL;
        if(strncmp($Result, "http://", strlen("http://")) != 0)
        {
            $Result =  "http://" . $Result;
        }
        return $Result;
    }
    
    function GetClientVersion($VersionInt)
    {
        $Version = (($VersionInt & 0xFF000000) >> 24) . "." . 
                   (($VersionInt & 0xFF0000) >> 16) . "." . 
                   (($VersionInt & 0xFF00) >> 8) . "." . 
                   ($VersionInt & 0xFF);

        return $Version;
    }

    function GetSzAdminRightsBool($AdminRightsBool)
    {
        if (isset($AdminRightsBool))
        {
            if ($AdminRightsBool == true)
            {
                return "Yes";
            }
            else if ($AdminRightsBool == false)
            {
                return "No";
            }
        }
        return "Unknown";
    }
    
    function RC4($key, $keysize, $data, $size) 
    {
        $krc = array();
        for ($i = 0; $i < 256; $i++) {
            $krc[$i] = $i;
        }

        $j = 0;
        for ($i = 0; $i < 256; $i++) 
        {
            $j = ($j + $krc[$i] + ord($key[$i % $keysize])) % 256;
            $x = $krc[$i];
            $krc[$i] = $krc[$j];
            $krc[$j] = $x;
        }

        $i = 0;
        $j = 0;
        $res = "";
        for ($x = 0; $x < $size; $x++) 
        {
            $i = ($i + 1) % 256;
            $j = ($j + $krc[$i]) % 256;
            $t = $krc[$i];
            $krc[$i] = $krc[$j];
            $krc[$j] = $t;
            $res .= chr(ord($data[$x]) ^ $krc[($krc[$i] + $krc[$j]) % 256]);
        }

        return $res;
    }
    
    function ExistSetupFile()
    {
        if(file_exists("setup.php"))
        {
            return true;
        }
        return false;
    }
    
    function ArraySort($Array, $Key, $Order = SORT_ASC)
    {
        $new_array = array();
        $sortable_array = array();

        if (count($Array) > 0) {
            foreach ($Array as $k => $v) {
                if (is_array($v)) {
                    foreach ($v as $k2 => $v2) {
                        if ($k2 == $Key) {
                            $sortable_array[$k] = $v2;
                        }
                    }
                } else {
                    $sortable_array[$k] = $v;
                }
            }

            switch ($Order) {
                case SORT_ASC:
                    asort($sortable_array);
                break;
                case SORT_DESC:
                    arsort($sortable_array);
                break;
            }

            foreach ($sortable_array as $k => $v) {
                $new_array[$k] = $Array[$k];
            }
        }

        return $new_array;
    }
?>