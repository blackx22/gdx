<?PHP
    
define("CAPTCHA_X", 220);
define("CAPTCHA_Y", 60);

    session_start();
    
    $Captcha = imagecreatetruecolor(CAPTCHA_X, CAPTCHA_Y) or die();
    $Background = imagecolorallocate($Captcha, 152, 172, 255);
    imagefill($Captcha, 0, 0, $Background);
    $linecolor = imagecolorallocate($Captcha, rand(50, 200), rand(50, 200), rand(50, 200));
    
    for($i=0; $i < 8; $i++)
    {
        imagesetthickness($Captcha, rand(2, 4));
        imageline($Captcha, rand(0, CAPTCHA_X), 0, rand(0, CAPTCHA_X), CAPTCHA_Y, $linecolor);
    }
    
    $Text = "";
    $Fonts = array("fonts/DejaVuSans-Bold.ttf", "fonts/DejaVuSansMono-Bold.ttf", "fonts/DejaVuSerif-Bold.ttf");
    $RandSz = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $RandSzLen = strlen($RandSz);
    
    for($x = 20; $x <= CAPTCHA_X - 20; $x += 40) 
    {
        $textcolor = imagecolorallocate($Captcha, rand(50, 200), rand(50, 200), rand(50, 200));
        $Text .= ($num = $RandSz[rand(0, $RandSzLen - 1)]);
        imagettftext($Captcha, 30, rand(-30, 30), $x, 40, $textcolor, $Fonts[array_rand($Fonts)], $num);
    }
    
    $_SESSION["CaptchaText"] = $Text;
    header('Content-type: image/png');
    imagepng($Captcha);
    imagedestroy($Captcha);
?>