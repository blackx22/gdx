<?php
    session_start();
    include_once("gdx/utility.php");
    include_once("gdx/gdx.php");
    include_once("gdx/internal.php");

    if(ExistSetupFile()) die("Delete setup.php");
    
    if(!isset($_SESSION['GDX_AUTHENTICATION']) && $_SESSION['GDX_AUTHENTICATION'] != 1)
    {
        header("Location: login.php");
        exit();
    }
    if(isset($_GET["op"]) && $_GET["op"] == GDX_LOGOUT_OPT)
    {
        unset($_SESSION["GDX_AUTHENTICATION"]);
        header("Location: login.php");
        exit();
    }
    
    if (isset($_GET["op"]))
        $option = $_GET["op"];
    else
        $option = GDX_CLIENTS_OPT;
    
    try
    {
        $Host = MYSQL_HOST;
        $Database = DATABASE_NAME;
        $conn = new PDO("mysql:host=$Host;dbname=$Database", MYSQL_USER, MYSQL_PASSWORD);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $gdx = new GDX($conn);
        echo $gdx->GdxPage($option);
        $conn = null;
    } catch (PDOException $err) {
        echo $err->getMessage();
    }
?>