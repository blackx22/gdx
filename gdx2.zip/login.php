<?php
    session_start();
    require_once("gdx/internal.php");

    if(isset($_SESSION["GDX_AUTHENTICATION"]) && $_SESSION["GDX_AUTHENTICATION"] == 1)
    {
        header("Location: main.php");
        exit();
    }

    if(isset($_POST["CaptchaInput"]) && isset($_POST["username"]) && isset($_POST["password"]))
    {
        if(isset($_SESSION["CaptchaText"]))
        {
            $CaptchaResolved = (strtolower($_POST["CaptchaInput"]) == strtolower($_SESSION["CaptchaText"])) ? true : false;
            unset($_SESSION["CaptchaText"]);
            
            if($CaptchaResolved)
            {
                try
                {
                    $Host = MYSQL_HOST;
                    $Database = DATABASE_NAME;
                    $conn = new PDO("mysql:host=$Host;dbname=$Database", MYSQL_USER, MYSQL_PASSWORD);
                    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                    
                    $ScAdmins = $conn->query("SELECT * FROM Admins");
                    $Admins = $ScAdmins->fetch(PDO::FETCH_ASSOC);
                    $PwHash = md5($_POST["password"]);
                    
                    if($_POST["username"] == $Admins["UserName"] && $PwHash == $Admins["PasswordHash"])
                    {
                        $_SESSION["GDX_AUTHENTICATION"] = 1;
                        header("Location: main.php");
                        exit();
                    }
                    else $err = "<p style='width: 100%; text-align: center; color: red'>Invalid username or password</p>";
                    $conn = null;
                }
                catch(PDOException $e) {
                    //echo $e->getMessage();
                }
            }
            else $err = "<p style='width: 100%; text-align: center; color: red'>Invalid captcha</p>";
        }
    }
?>

<!DOCTYPE HTML>
<html>
<head>
    <link href='css/gdx.css' rel='stylesheet' type='text/css'/>
</head>
<body class='login-body'>
<div class='login-container'>
    <div class='login-inner'>
        <div class='div-form'>
            <div class='login-container'>
                <div class='login-inner'>
                    <div class='form-login-inner'>
                        <form action='' method='post'>
                            <p class='form-login-label'>UserName: </p>
                            <input class='form-login-ctrl' type='text' name='username'>
                            <br/><br/>
                            <p class='form-login-label'>Password: </p>
                            <input class='form-login-ctrl' type='password' name='password'>
                            <br/><br/>
                            <div align='middle'>
                                <img id='captcha' src='captcha.php' width='220' height='60' border='1' alt='CAPTCHA'>
                            </div>
                            <br/>
                            <input style='font-size: 16px; width: 190px' id='CaptchaId' type='text' name='CaptchaInput'> 
                            
                            <a  style='cursor: pointer' onclick="document.getElementById('captcha').src = 'captcha.php?' + Math.random();
                                document.getElementById('CaptchaId').value = ''; return false;">
                                <img src='images/refresh.png' width='20' height='20'>
                            </a>
                            <div>
                                <br/>
                                <?php echo (isset($err)) ? $err : "<p><br/></p>"; ?>
                                <input class='form-login-ctrl' type='submit' value='Login In'>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>